import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-homee',
  templateUrl: './homee.component.html',
  styleUrls: ['./homee.component.css']
})
export class HomeeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
