import { Component, OnInit } from '@angular/core';
import { viewcomponentService } from '../view.service';
import { itemsmodel } from '../items';
import { FormGroup, FormControl, Validators } from '@angular/forms';
@Component({
  selector: 'app-place-appointment',
  templateUrl: './place-appointment.component.html',
  styleUrls: ['./place-appointment.component.css']
})
export class PlaceAppointmentComponent implements OnInit {

  form = new FormGroup({
    firstName: new FormControl('', Validators.required),
    lastName: new FormControl('', Validators.required),
    age: new FormControl('', [
      Validators.required,
    ]),
    
    phone: new FormControl('', [
      Validators.required,
      Validators.minLength(10)
    ]),

    email: new FormControl('', [
      Validators.required,
      Validators.email
    ]),
    
    password: new FormControl('', [
      Validators.required,
      Validators.minLength(6)
    ])
    
   });

  name:String;
  Addresss:String;
  city:String;
  package:String="premium";
  trainerreference:String="srvani";
  phone:number;
  itemsmodels:itemsmodel[];
  items = new itemsmodel();
  itemsmode:itemsmodel[];
  constructor(private dataservic:viewcomponentService){}

  ngOnInit(): void {
  }
  addcom()
{ 
  console.log("in placecom");

  this.items.name=this.name;
  this.items.Addresss=this.Addresss;
  this.items.city=this.city;
  this.items.package=this.package;
  this.items.trainerreference=this.trainerreference;
  this.items.phone=this.phone;
  this.dataservic.postview(this.items).subscribe(itemsmodel=>this.itemsmode=itemsmodel);
}

onSubmit(){
  alert(JSON.stringify(this.form.value));
}
}
