# angular-bootstrap-example

[![Build Status](https://travis-ci.org/loiane/angular-bootstrap-example.svg?branch=master)](https://travis-ci.org/loiane/angular-bootstrap-example)
